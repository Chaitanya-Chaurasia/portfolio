// Personal site — plaintext / monospace aesthetic
// Single column, hover-reveal links, ASCII flourishes, guestbook, last-updated footer.

const { useState, useEffect, useMemo } = React;

// ---------- palettes ----------
const PALETTES = {
  paper: {
    label: "paper",
    bg: "#faf8f3", ink: "#1a1a1a", muted: "#8a857a",
    rule: "#d8d3c5", link: "#1d4ed8", linkHover: "#0b2a8a",
    accentBg: "#f1ebda",
  },
  ivory: {
    label: "ivory",
    bg: "#f4ede0", ink: "#2a2418", muted: "#7a6a4d",
    rule: "#d6c9a8", link: "#a85a1c", linkHover: "#7a3e0c",
    accentBg: "#ebe1c8",
  },
  classic: {
    label: "classic",
    bg: "#ffffff", ink: "#000000", muted: "#666666",
    rule: "#cccccc", link: "#0000ee", linkHover: "#551a8b",
    accentBg: "#f3f3f3",
  },
  terminal: {
    label: "terminal",
    bg: "#0e0e10", ink: "#e8e8e6", muted: "#888888",
    rule: "#2a2a2e", link: "#7dd3a0", linkHover: "#a8e6c1",
    accentBg: "#17171a",
  },
};

const FONTS = {
  mono: 'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace',
  serif: 'Georgia, "Iowan Old Style", "Apple Garamond", Garamond, "Times New Roman", serif',
  sans: '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, Arial, sans-serif',
};

// ---------- inline link with hover-reveal meta (via title attr) ----------
function ILink({ href, children, meta }) {
  return <a href={href} title={meta}>{children}</a>;
}

// ---------- content ----------
const NOW_ITEMS = [
  "writing more, shipping more, scrolling less.",
  "reading: a book on attention, a book on cities.",
  "tinkering with a notes app that respects plaintext.",
  "open to interesting conversations — see contact below.",
];

const PROJECTS = [
  { name: "project-one",   year: "2026", href: "#", desc: "a small tool for [thing]. plaintext-first, syncs across devices." },
  { name: "project-two",   year: "2025", href: "#", desc: "a weekend experiment that became a habit. ~3k users." },
  { name: "project-three", year: "2024", href: "#", desc: "open-source library for [thing]. archived but still works." },
];

const POSTS = [
  { title: "on writing less and meaning more",      date: "2026-04-12", href: "#", desc: "a short essay on subtraction." },
  { title: "the case for plaintext personal sites", date: "2026-02-28", href: "#", desc: "why html is enough." },
  { title: "notes from a slow december",            date: "2025-12-20", href: "#", desc: "field notes, mostly." },
  { title: "how i take notes (the boring version)", date: "2025-09-04", href: "#", desc: "tooling, not philosophy." },
];

const LINKS = [
  { label: "twitter", href: "#", meta: "@placeholder — mostly quiet" },
  { label: "github",  href: "#", meta: "@placeholder — code lives here" },
  { label: "email",   href: "#", meta: "hello [at] placeholder.com" },
  { label: "rss",     href: "#", meta: "for the feed-readers among us" },
];

// ---------- ascii ----------
const ASCII_RULES = ["~ ~ ~", "* * *", "— · — · —", "·  ·  ·", "/ / /"];
function Rule({ i = 0 }) {
  return <div className="rule" aria-hidden="true">{ASCII_RULES[i % ASCII_RULES.length]}</div>;
}

function Row({ href, label, meta, date, bullet = "—" }) {
  return (
    <span className="row">
      <span className="bullet">{bullet} </span>
      <a href={href}>{label}</a>
      {date && <span className="date">· {date}</span>}
      {meta && <span className="reveal">{meta}</span>}
    </span>
  );
}

function Section({ id, title, children, ruleIndex = 0 }) {
  return (
    <section id={id} style={{ scrollMarginTop: 24 }}>
      <Rule i={ruleIndex} />
      <h2 className="section-head">{title}</h2>
      <div>{children}</div>
    </section>
  );
}

function Intro() {
  return (
    <>
      <p>
        hi, i'm <strong>chaitanya chaurasia</strong>. i live in [city] and spend most of my time{" "}
        <ILink href="#projects" meta="building small tools and writing about them">building small tools</ILink>{" "}
        and writing.
      </p>
      <p>
        i'm interested in software, language, and the slow web. this site is a{" "}
        <ILink href="#" meta="no js frameworks, no analytics, no cookie banners">deliberately plain</ILink>{" "}
        corner of the internet — text first, links underlined, no animations you didn't ask for.
      </p>
      <p>previously: thechai.fyi (this site, but louder).</p>
    </>
  );
}

function NowBlock() {
  return (
    <div className="now">
      {NOW_ITEMS.map((line, i) => (
        <div key={i}><span style={{ color: "var(--rule)" }}>{">"} </span>{line}</div>
      ))}
    </div>
  );
}

function ProjectsList() {
  return (
    <div>
      {PROJECTS.map((p) => (
        <Row key={p.name} href={p.href} label={p.name} date={p.year} meta={p.desc} />
      ))}
    </div>
  );
}

function WritingList() {
  return (
    <div>
      {POSTS.map((p) => (
        <Row key={p.title} href={p.href} label={p.title} date={p.date} meta={p.desc} />
      ))}
      <div style={{ marginTop: 10 }}><a href="#">all posts →</a></div>
    </div>
  );
}

function LinksList() {
  return (
    <div>
      {LINKS.map((l) => (
        <Row key={l.label} href={l.href} label={l.label} meta={l.meta} />
      ))}
    </div>
  );
}

// ---------- guestbook ----------
const GUESTBOOK_KEY = "chai_guestbook_v1";
const SEED_ENTRIES = [
  { who: "anonymous", when: "2026-04-30", msg: "love the new look. very calm." },
  { who: "a friend",  when: "2026-04-22", msg: "you finally killed the gradient. proud of you." },
];

function Guestbook() {
  const [entries, setEntries] = useState(() => {
    try {
      const raw = localStorage.getItem(GUESTBOOK_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return SEED_ENTRIES;
  });
  const [who, setWho] = useState("");
  const [msg, setMsg] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    try { localStorage.setItem(GUESTBOOK_KEY, JSON.stringify(entries)); } catch (e) {}
  }, [entries]);

  function submit(e) {
    e.preventDefault();
    const trimmedWho = who.trim() || "anonymous";
    const trimmedMsg = msg.trim();
    if (!trimmedMsg) { setStatus("(say something first.)"); return; }
    const today = new Date().toISOString().slice(0, 10);
    setEntries([{ who: trimmedWho, when: today, msg: trimmedMsg }, ...entries].slice(0, 20));
    setWho(""); setMsg("");
    setStatus("(signed. thanks for stopping by.)");
    setTimeout(() => setStatus(""), 3500);
  }

  return (
    <div>
      <p className="meta" style={{ marginBottom: 10 }}>
        leave a note. nothing is sent anywhere — entries live in your browser only.
      </p>
      <form className="guestbook" onSubmit={submit}>
        <label htmlFor="gb-who">name (optional)</label>
        <input id="gb-who" value={who} onChange={(e) => setWho(e.target.value)} placeholder="anonymous" maxLength={40} />
        <label htmlFor="gb-msg">message</label>
        <textarea id="gb-msg" value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="say hi…" maxLength={400} />
        <button type="submit">[ sign guestbook ]</button>
        {status && <span className="meta" aria-live="polite">{status}</span>}
      </form>
      <ul className="entries">
        {entries.map((e, i) => (
          <li className="entry" key={i}>
            <span className="who">{e.who}</span>
            <span className="when">· {e.when}</span>
            <div className="msg">{e.msg}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---------- header / footer ----------
function Header({ tweaks }) {
  return (
    <>
      <pre className="ascii">{`chaitanya chaurasia
———————————————————`}</pre>
      <nav className="nav-top">
        {tweaks.showIntro     && <a href="#intro">intro</a>}
        {tweaks.showNow       && <a href="#now">now</a>}
        {tweaks.showProjects  && <a href="#projects">projects</a>}
        {tweaks.showWriting   && <a href="#writing">writing</a>}
        {tweaks.showLinks     && <a href="#links">links</a>}
        {tweaks.showGuestbook && <a href="#guestbook">guestbook</a>}
      </nav>
    </>
  );
}

function Foot() {
  const updated = useMemo(() => new Date().toISOString().slice(0, 10), []);
  return (
    <footer className="foot">
      <span>made by hand · plaintext, no tracking</span>
      <span>last updated {updated}</span>
    </footer>
  );
}

// ---------- root ----------
function App() {
  const [tweaks, setTweak] = window.useTweaks(window.__TWEAK_DEFAULTS);

  // apply css vars from tweaks
  useEffect(() => {
    const root = document.documentElement;
    const p = PALETTES[tweaks.palette] || PALETTES.paper;
    root.style.setProperty("--bg", p.bg);
    root.style.setProperty("--ink", p.ink);
    root.style.setProperty("--muted", p.muted);
    root.style.setProperty("--rule", p.rule);
    root.style.setProperty("--link", p.link);
    root.style.setProperty("--link-hover", p.linkHover);
    root.style.setProperty("--accent-bg", p.accentBg);
    root.style.setProperty("--max-w", `${tweaks.maxWidth}px`);
    root.style.setProperty("--lh", String(tweaks.lineHeight));
    root.style.setProperty("--font", FONTS[tweaks.fontFamily] || FONTS.mono);
  }, [tweaks]);

  const Tw = window.TweaksPanel;
  const Sec = window.TweakSection;
  const Slider = window.TweakSlider;
  const Radio = window.TweakRadio;
  const Toggle = window.TweakToggle;
  const Select = window.TweakSelect;

  let ruleI = 0;
  return (
    <>
      <main className="page">
        <Header tweaks={tweaks} />

        {tweaks.showIntro && (
          <Section id="intro" title="intro" ruleIndex={ruleI++}>
            <Intro />
          </Section>
        )}

        {tweaks.showNow && (
          <Section id="now" title="now" ruleIndex={ruleI++}>
            <NowBlock />
          </Section>
        )}

        {tweaks.showProjects && (
          <Section id="projects" title="projects" ruleIndex={ruleI++}>
            <p className="meta" style={{ marginBottom: 8 }}>things i made. hover for details.</p>
            <ProjectsList />
          </Section>
        )}

        {tweaks.showWriting && (
          <Section id="writing" title="writing" ruleIndex={ruleI++}>
            <p className="meta" style={{ marginBottom: 8 }}>recent posts, newest first.</p>
            <WritingList />
          </Section>
        )}

        {tweaks.showLinks && (
          <Section id="links" title="links" ruleIndex={ruleI++}>
            <LinksList />
          </Section>
        )}

        {tweaks.showGuestbook && (
          <Section id="guestbook" title="guestbook" ruleIndex={ruleI++}>
            <Guestbook />
          </Section>
        )}

        <Foot />
      </main>

      {Tw && (
        <Tw title="Tweaks">
          <Sec label="type">
            <Radio
              label="font"
              value={tweaks.fontFamily}
              options={[
                { value: "mono",  label: "mono" },
                { value: "serif", label: "serif" },
                { value: "sans",  label: "sans" },
              ]}
              onChange={(v) => setTweak("fontFamily", v)}
            />
            <Slider
              label="line height"
              value={tweaks.lineHeight}
              min={1.3} max={2.1} step={0.05}
              onChange={(v) => setTweak("lineHeight", v)}
            />
            <Slider
              label="max width"
              value={tweaks.maxWidth}
              min={420} max={880} step={10} unit="px"
              onChange={(v) => setTweak("maxWidth", v)}
            />
          </Sec>

          <Sec label="palette">
            <Select
              label="theme"
              value={tweaks.palette}
              options={[
                { value: "paper",    label: "paper (warm off-white)" },
                { value: "ivory",    label: "ivory (warm + ochre)" },
                { value: "classic",  label: "classic (white + blue)" },
                { value: "terminal", label: "terminal (dark)" },
              ]}
              onChange={(v) => setTweak("palette", v)}
            />
          </Sec>

          <Sec label="sections">
            <Toggle label="intro"     value={tweaks.showIntro}     onChange={(v) => setTweak("showIntro", v)} />
            <Toggle label="now"       value={tweaks.showNow}       onChange={(v) => setTweak("showNow", v)} />
            <Toggle label="projects"  value={tweaks.showProjects}  onChange={(v) => setTweak("showProjects", v)} />
            <Toggle label="writing"   value={tweaks.showWriting}   onChange={(v) => setTweak("showWriting", v)} />
            <Toggle label="links"     value={tweaks.showLinks}     onChange={(v) => setTweak("showLinks", v)} />
            <Toggle label="guestbook" value={tweaks.showGuestbook} onChange={(v) => setTweak("showGuestbook", v)} />
          </Sec>
        </Tw>
      )}
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
