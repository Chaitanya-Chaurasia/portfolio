# Handoff: Personal Site (thechai.fyi redesign)

## Overview

A personal website redesign for **Chaitanya Chaurasia** in a deliberately plain, plaintext-flavored aesthetic. Single column, monospace by default, ASCII rule separators, hover-to-reveal link metadata, and a working local-only guestbook. The goal is a calm, text-first corner of the internet — no animations the visitor didn't ask for, no gradient hero, no analytics, no cookie banners.

## About the Design Files

The files in this bundle (`index.html`, `site.jsx`, `tweaks-panel.jsx`) are **design references created in HTML** — a working prototype showing the intended look and behavior. They are **not** production code to ship as-is.

The task is to **recreate this design in the target codebase's existing environment** (Next.js, Astro, plain HTML+CSS, Eleventy, etc.) using its established patterns. If no codebase exists yet, **plain static HTML + CSS is the correct choice for this design** — there is nothing here that needs React in production. The Tweaks panel and React in the prototype are scaffolding for design iteration; in the shipped site, the chosen tweak values become hard-coded CSS.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, and interactions are all decided. Recreate pixel-faithfully.

## Final tweak values (locked in by the user)

The user adjusted the prototype's tweaks and these are the values to ship:

| Token       | Final value |
|-------------|-------------|
| Font family | **sans** (`-apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, Arial, sans-serif`) |
| Line height | **1.3**     |
| Max width   | **440px**   |
| Palette     | **classic** (white background, black ink, classic-web blue links) |

Hard-code these. The other palettes/fonts in the prototype are exploration, not options to ship.

## Page structure (single page, single column)

The whole site is one page, scrolled top to bottom. Anchor nav at the top jumps to sections.

Top → bottom order:

1. **Header**
   - `<pre>` block with the name `chaitanya chaurasia` followed by an em-dash rule line of the same width
   - Anchor nav: `intro · now · projects · writing · links · guestbook` (links in muted color, no underline until hover)

2. **Section: intro** — short bio, 3 paragraphs. Two inline links carry hover metadata (browser title attribute is fine).

3. **Section: now** — a small box with off-white/very-faint background, 4 lines each prefixed with `>`, a `/* now */` comment label above.

4. **Section: projects** — list of 3 rows. Each row: `— project-name · 2026` then a hover-revealed description on the next line.

5. **Section: writing** — list of 4 post rows in the same format, `· YYYY-MM-DD` after each title, hover-revealed description. "all posts →" link below.

6. **Section: links** — list of social/contact rows (twitter, github, email, rss). Same hover-reveal pattern.

7. **Section: guestbook** — name + message form, button labelled `[ sign guestbook ]`, list of past entries. Entries persist in `localStorage` only — nothing is sent anywhere.

8. **Footer** — top dashed border. Left: `made by hand · plaintext, no tracking`. Right: `last updated YYYY-MM-DD`.

Between every section there is an ASCII rule, cycling through:
```
~ ~ ~
* * *
— · — · —
·  ·  ·
/ / /
```
Rendered in the muted "rule" color, `user-select: none`.

## Layout

- Outer `<main>` is centered: `max-width: 440px`, horizontal padding `28px`, top padding `64px`, bottom padding `96px`. On viewports ≤520px wide, drop top/bottom padding to `36px`/`64px` and base font size from 15px to 14px.
- Single column. No grid. No multi-column anywhere.
- Section spacing comes entirely from the ASCII rule's `margin: 28px 0`.
- Section heading style: muted color, prefixed with `## ` (two hash characters + space) in the rule color. Heading text itself in muted, normal weight, normal size — it is *not* a typographic heading, just a label.

## Design tokens (final, palette = classic)

```
--bg:         #ffffff
--ink:        #000000
--muted:      #666666
--rule:       #cccccc
--link:       #0000ee   /* unvisited and visited render the same on this site */
--link-hover: #551a8b
--accent-bg:  #f3f3f3   /* used only for the "now" block background */

font:         -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, Arial, sans-serif
font-size:    15px (14px ≤520px)
line-height:  1.3
max-width:    440px
```

Selection: `background: var(--ink); color: var(--bg);`

## Component specs

### Inline links
- `color: var(--link); text-decoration: underline; text-underline-offset: 2px; text-decoration-thickness: 1px;`
- On hover: `color: var(--link-hover); text-decoration-thickness: 2px;`
- `:visited` deliberately renders the same as unvisited (`color: var(--link)`).

### Top nav
- Flex row, `gap: 8px 18px`, wraps.
- Links: muted color, **no underline**. On hover: ink color, underline appears.
- Bottom margin `32px`.

### Section heading (`<h2 class="section-head">`)
- Inherits font size/weight from body — same size as body text.
- Color `var(--muted)`.
- `::before` pseudo-element prepends `## ` in `var(--rule)`.
- Bottom margin `14px`.

### Row (used by projects, writing, links)
The hover-reveal pattern:

```html
<span class="row">
  <span class="bullet">— </span>
  <a href="…">project-name</a>
  <span class="date">· 2026</span>
  <span class="reveal">a small tool for [thing]. plaintext-first, syncs across devices.</span>
</span>
```

- `.row` is `display: block; margin: 6px 0; position: relative;`.
- `.bullet` color is `var(--rule)`, `user-select: none`.
- `.date` is muted, prefixed by `· ` (with one space of left margin via `margin-left: 1ch`).
- `.reveal` is the metadata line. **Default state**: `display: block; max-height: 0; overflow: hidden; opacity: 0; margin: 0; padding-left: 2ch; color: var(--muted);`
- **On `.row:hover` and `.row:focus-within`**: `max-height: 80px; opacity: 1; margin: 2px 0 8px;`
- Transition: `max-height 220ms ease, opacity 180ms ease 40ms, margin 220ms ease`.
- For text-only inline links inside paragraphs (intro), the equivalent metadata is exposed via the native `title` attribute — no custom tooltip needed.

### "Now" block
```css
.now {
  background: var(--accent-bg);
  padding: 14px 16px;
}
.now::before {
  content: "/* now */";
  color: var(--muted);
  display: block;
  margin-bottom: 6px;
  font-size: 13px;
}
```
Each line inside is `<div>`-wrapped and prefixed with a `>` glyph rendered in `var(--rule)` color, then a space, then the line in default ink.

### Guestbook form

- `display: grid; gap: 8px;` for the form layout.
- Labels above their inputs, color muted, font-size 13px.
- Inputs / textarea:
  - `background: transparent;`
  - `color: var(--ink);`
  - `border: 1px dashed var(--rule);`
  - `padding: 8px 10px;`
  - `font: inherit;`
  - `border-radius: 0;`
  - `width: 100%; box-sizing: border-box;`
  - On focus: `border-color: var(--ink); border-style: solid;`
  - Textarea `min-height: 72px; resize: vertical;`
- Submit button:
  - Text content: `[ sign guestbook ]`
  - `background: var(--ink); color: var(--bg); border: 0; padding: 8px 14px; border-radius: 0; cursor: pointer;`
  - On hover: `background: var(--link);`
  - `justify-self: start` so it doesn't stretch.
- After submit, render `(signed. thanks for stopping by.)` in muted text for ~3.5s, then clear.
- Empty-message submission renders `(say something first.)` in muted.

### Guestbook entries list
- Each entry separated by `border-top: 1px dashed var(--rule); padding-top: 8px;`.
- Top line: `<name>` in ink, then `· YYYY-MM-DD` in muted at font-size 13px with `margin-left: 1ch`.
- Body in ink, `white-space: pre-wrap`, `margin-top: 2px`.

### Footer
- `margin-top: 48px; border-top: 1px dashed var(--rule); padding-top: 16px;`
- Flex with `justify-content: space-between; flex-wrap: wrap; gap: 8px;`
- Color muted, font-size 13px.
- Left text: `made by hand · plaintext, no tracking`
- Right text: `last updated YYYY-MM-DD` (the date the page was deployed — generate at build time, not on every page load)

## Interactions & behavior

- **Hover-to-reveal rows**: described above. Driven entirely by CSS `:hover`/`:focus-within` — no JS needed in production.
- **Anchor nav**: standard fragment links. Each section needs `scroll-margin-top: 24px` so jumps don't tuck under the top edge.
- **Guestbook persistence**: `localStorage` key `chai_guestbook_v1`, JSON array of `{ who, when, msg }`. Cap at 20 entries. Seed with two example entries on first visit so the section never looks empty.
- **No analytics, no third-party scripts, no cookie banner.** That is part of the design.
- **No dark/light toggle.** The user picked classic (white) and that is final.

## State management

Only the guestbook has state — and only on the client.

- `entries: { who: string, when: 'YYYY-MM-DD', msg: string }[]` — read from `localStorage` on mount, fall back to seed array, write back on every change.
- `who`, `msg` — controlled form inputs.
- `status` — transient string for post-submit message.

If you ship this as static HTML, this is ~30 lines of vanilla JS at the bottom of the page.

## Copy / content

All copy in the prototype is placeholder for the real Chaitanya. The user said "just add placeholders for now" for socials, and to leave `[city]` as a literal placeholder in the intro until they fill it in. **Do not invent personal details, real twitter handles, or real project names.**

The placeholder strings to preserve verbatim:
- `[city]` in the intro
- `[thing]` in two project descriptions
- `@placeholder`, `hello [at] placeholder.com` in the links section
- The two seed guestbook entries (signal that the guestbook is alive)

## Things from the prototype to ignore in production

- `tweaks-panel.jsx` and the `<TweaksPanel>` invocation in `site.jsx` — design-time only, do not ship.
- The `__TWEAK_DEFAULTS` block and the `EDITMODE-BEGIN`/`EDITMODE-END` markers — design-time only.
- The `PALETTES` object — only the `classic` entry's values matter; bake them into CSS as the tokens above.
- The `FONTS` object — only the `sans` entry matters.
- React, ReactDOM, Babel `<script>` tags — not needed for the shipped site.

## Files in this bundle

- `index.html` — outer shell, CSS, tweak default block. The CSS in the `<style>` tag is the source of truth for layout and component styling.
- `site.jsx` — React rendering of the page content. Read this to see structure, copy, and interaction logic. Translate component-by-component into the target framework (or to plain HTML + a tiny vanilla JS guestbook).
- `tweaks-panel.jsx` — design-time only. Ignore for implementation.

## Suggested implementation path (plain static HTML)

1. Start a single `index.html` with the `<style>` block from the prototype, dropping all CSS variables that aren't used by the classic palette.
2. Hand-write each section's markup directly from `site.jsx`. The structure is small and unchanging — there is no list to template-render.
3. Add ~30 lines of vanilla JS at the bottom for the guestbook (load → render → submit → save → re-render).
4. Set the footer's `last updated` from your build script, not from `new Date()` in the page.
